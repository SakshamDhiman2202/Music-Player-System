"""Django project package."""
