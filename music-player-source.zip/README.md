# SoundRoom · MusicPlayer

A fully-featured web-based music player application (Spotify-style) built with **Django 5** and vanilla JavaScript. Features a global player bar, user authentication, playlists, favorites, play history tracking, and a custom song management admin interface.

---

## ✨ Features

### 🎵 Music Player
- Global fixed-bottom player bar visible on every page
- Play / Pause, Next / Previous track navigation
- Shuffle & Repeat modes
- Volume control slider
- Draggable progress bar with elapsed / total time display
- Keyboard shortcuts: `Space` (play/pause), `←` (prev), `→` (next)
- Auto-play next song when current track ends

### 👤 User Features
- Register, Sign in, Sign out
- Mark songs as favorites (♥ toggle with AJAX)
- View your favorites page
- Automatic play history tracking
- Recently played page
- Create custom playlists

### 🛠️ Admin / Song Management
- **Custom song management page** (`/manage-songs/`) – for staff/superusers
  - Add new songs with title, artist, album, genre, duration, audio file, cover image
  - Edit existing songs
  - Delete songs with confirmation
  - Search by title or artist
  - Paginated table with inline audio preview
  - Auto-detect duration from uploaded audio file
- Full Django admin panel at `/admin/`

### 📦 Tech Stack
| Layer | Technology |
|-------|-----------|
| Backend | Django 5.0.1, Python 3.11 |
| Frontend | Vanilla JS, CSS custom properties |
| Database | SQLite (dev) / PostgreSQL (production) |
| Static files | WhiteNoise (compressed & cached) |
| WSGI server | Gunicorn |
| Containerization | Docker + docker-compose |
| Dependencies | Pillow, mutagen, python-decouple, whitenoise |

---

## 🚀 Quick Start (Development)

> **Prerequisites**: Python 3.9+ and pip

```bash
# 1. Enter the project directory
cd Music-Player-main

# 2. Create virtual environment & activate it
python3 -m venv venv
source venv/bin/activate

# 3. Upgrade pip (avoids SSL issues on macOS)
pip install --upgrade pip

# 4. Install dependencies
pip install -r requirements.txt

# 5. Run database migrations
python manage.py migrate

# 6. Create a superuser (admin account)
python manage.py createsuperuser

# 7. Create media directories (for song uploads)
mkdir -p media/songs media/covers media/avatars

# 8. Start the development server
python manage.py runserver
```

Open **http://localhost:8000** in your browser.

---

## 🐳 Production Deployment with Docker

The project includes a production-ready `docker-compose.yml` that runs PostgreSQL + Gunicorn.

### 1. Prerequisites
- Docker & Docker Compose installed on your server

### 2. Clone & Configure

```bash
git clone <your-repo-url> MusicPlayer
cd MusicPlayer

# Copy environment template & edit it
cp .env.example .env
# Edit .env with:
#   SECRET_KEY=your-long-random-secret
#   DEBUG=False
#   ALLOWED_HOSTS=yourdomain.com,www.yourdomain.com
#   CSRF_TRUSTED_ORIGINS=https://yourdomain.com,https://www.yourdomain.com
#   DB_PASSWORD=strong-db-password
#   DJANGO_SUPERUSER_USERNAME=admin
#   DJANGO_SUPERUSER_PASSWORD=your-admin-password
#   DJANGO_SUPERUSER_EMAIL=admin@example.com
#   SECURE_SSL_REDIRECT=True
```

### 3. Build & Run

```bash
docker compose up -d --build
```

The application will be available at **http://localhost:8000** (or your domain behind a reverse proxy).

### 4. Useful Commands

| Command | Description |
|---------|-------------|
| `docker compose up -d` | Start services in background |
| `docker compose down` | Stop services |
| `docker compose logs -f web` | Follow web service logs |
| `docker compose exec web python manage.py shell` | Django shell |
| `docker compose exec web python manage.py migrate` | Run migrations manually |
| `docker compose exec web python manage.py createsuperuser` | Create admin manually |

### 5. Production Checklist

- [ ] Set a strong, unique `SECRET_KEY` in `.env`
- [ ] Set `DEBUG=False`
- [ ] Set `ALLOWED_HOSTS` to your domain(s)
- [ ] Set `CSRF_TRUSTED_ORIGINS` to your domain(s) with HTTPS
- [ ] Set `SECURE_SSL_REDIRECT=True` (requires HTTPS termination at reverse proxy)
- [ ] Change `POSTGRES_PASSWORD` and `DB_PASSWORD` in docker-compose.yml
- [ ] Use a reverse proxy (nginx / Caddy / Traefik) with HTTPS in front

---

## 🎛️ Custom Song Management Page

Instead of the default Django admin, this project includes a custom, user-friendly song management page at **`/manage-songs/`**.

**Access**: Only staff users and superusers can access it.

### Features:
- **Add songs**: Fill in title, artist, album, genre, duration, upload audio file & cover image
- **Edit songs**: Click "Edit" on any song to pre-populate the form
- **Delete songs**: One-click delete with confirmation dialog
- **Search**: Filter songs by title or artist
- **Inline preview**: Listen to any song directly in the table via `<audio>` tag
- **Auto-duration**: When you upload an audio file, the browser automatically detects the duration
- **Pagination**: Navigate through large song collections

---

## 🎹 Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `Space` | Play / Pause |
| `←` | Previous song |
| `→` | Next song |

---

## 📁 Project Structure

```
MusicPlayer/
├── manage.py              # Django CLI
├── requirements.txt       # Python dependencies
├── .env.example           # Environment variable template
├── Dockerfile             # Production Docker image
├── docker-compose.yml     # Multi-service orchestration
├── entrypoint.sh          # Container startup script
├── .dockerignore          # Files excluded from Docker build
│
├── musicplayer/           # Django project config
│   ├── settings.py        # Settings (env-aware)
│   ├── urls.py            # Root URL config + error handlers
│   ├── wsgi.py            # WSGI entry point
│   └── asgi.py            # ASGI entry point
│
├── music/                 # Main application
│   ├── models.py          # Song, Playlist, Favorite, PlayHistory, UserProfile
│   ├── views.py           # All views including manage_songs
│   ├── urls.py            # App URL routes
│   ├── admin.py           # Django admin registration
│   ├── apps.py            # App config
│   └── migrations/        # Database migrations
│
├── templates/             # HTML templates
│   ├── 404.html           # Custom 404 page
│   ├── 500.html           # Custom 500 page
│   ├── 403.html           # Custom 403 page
│   └── music/
│       ├── home.html           # Main player page
│       ├── manage_songs.html   # Custom song admin
│       ├── favorites.html      # User favorites
│       ├── recently_played.html
│       └── auth/
│           ├── login.html
│           └── register.html
│
├── staticfiles/           # Collected static assets (production)
├── media/                 # User-uploaded content
└── logs/                  # Application logs (production)
```

---

## 📡 API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/song/<id>/` | GET | Song details (JSON) |
| `/api/play-history/` | POST | Record a play |
| `/api/toggle-favorite/` | POST | Toggle favorite status |
| `/api/add-to-playlist/` | POST | Add song to playlist |

---

## 🔧 Environment Variables

All configurable via `.env` file or environment variables:

| Variable | Default | Description |
|----------|---------|-------------|
| `SECRET_KEY` | `insecure-dev-key...` | Django secret key (MUST change in prod) |
| `DEBUG` | `True` | Debug mode |
| `ALLOWED_HOSTS` | `localhost,127.0.0.1` | Comma-separated hosts |
| `CSRF_TRUSTED_ORIGINS` | `http://localhost:8000,...` | Comma-separated origins |
| `DB_ENGINE` | `sqlite3` | Database engine |
| `DB_NAME` | `musicplayer_db` | Database name |
| `DB_USER` | `postgres` | Database user |
| `DB_PASSWORD` | `` | Database password |
| `DB_HOST` | `localhost` | Database host |
| `DB_PORT` | `5432` | Database port |
| `MEDIA_ROOT` | `./media` | Media files directory |
| `SECURE_SSL_REDIRECT` | `False` | Redirect HTTP → HTTPS |

---

## 🔐 Security

- `SECRET_KEY` is validated — **production deployment will crash** if not set
- `ALLOWED_HOSTS` validated against request host
- CSRF protection enforced with configurable trusted origins
- CORS headers configured for allowed origins
- Clickjacking protection (`X-Frame-Options: DENY`)
- Content-Type sniffing disabled
- XSS filter enabled
- HSTS enabled when SSL redirect is active
- Default file upload limit: 50 MB

---

## 🧪 Browser Support

- Chrome / Chromium — ✅ Full support
- Firefox — ✅ Full support
- Safari 15+ — ✅ Full support
- Edge — ✅ Full support

---

## 📄 License

This project is open source and available for educational and personal use.

---

**Happy listening! 🎵**

