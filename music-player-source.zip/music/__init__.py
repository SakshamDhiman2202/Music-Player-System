"""Music application package."""
