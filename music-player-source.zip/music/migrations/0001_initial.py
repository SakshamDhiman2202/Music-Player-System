from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True
    dependencies = []
    operations = [
        migrations.SeparateDatabaseAndState(
            state_operations=[
                migrations.CreateModel(
                    name="Song",
                    fields=[
                        ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                        ("title", models.CharField(max_length=200)),
                        ("artist", models.CharField(max_length=200)),
                        ("album", models.CharField(blank=True, max_length=200)),
                        ("genre", models.CharField(blank=True, max_length=100)),
                        ("audio_file", models.FileField(blank=True, upload_to="songs/")),
                        ("cover_image", models.ImageField(blank=True, upload_to="covers/")),
                        ("duration", models.PositiveIntegerField(default=0, help_text="Duration in seconds")),
                        ("play_count", models.PositiveIntegerField(default=0)),
                    ],
                    options={"ordering": ["title"]},
                ),
            ],
            database_operations=[],
        ),
    ]
