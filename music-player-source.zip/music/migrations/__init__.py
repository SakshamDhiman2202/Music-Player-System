"""Database migrations for the music application."""
