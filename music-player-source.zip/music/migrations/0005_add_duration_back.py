from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("music", "0004_add_uploaded_by_field"),
    ]

    operations = [
        migrations.AddField(
            model_name="song",
            name="duration",
            field=models.PositiveIntegerField(default=0, help_text="Duration in seconds"),
        ),
    ]
