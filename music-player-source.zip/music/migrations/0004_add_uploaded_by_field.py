from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ("music", "0003_favorite_playhistory_playlist_userprofile_and_more"),
    ]

    operations = [
        migrations.AddField(
            model_name="song",
            name="uploaded_by",
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="uploaded_songs",
                to=settings.AUTH_USER_MODEL,
            ),
        ),
        migrations.AlterModelOptions(
            name="song",
            options={"ordering": ["-created_at"]},
        ),
    ]
