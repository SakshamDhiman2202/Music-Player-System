from django.urls import path
from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("register/", views.register, name="register"),
    path("favorites/", views.favorites, name="favorites"),
    path("recently-played/", views.recently_played, name="recently_played"),
    path("playlists/create/", views.create_playlist, name="create_playlist"),
    path("manage-songs/", views.manage_songs, name="manage_songs"),
    path("my-uploads/", views.my_uploads, name="my_uploads"),
    path("user/<str:username>/", views.user_profile, name="user_profile"),
    path("api/song/<int:song_id>/", views.song_detail, name="song_detail"),
    path("api/play-history/", views.record_play, name="record_play"),
    path("api/toggle-favorite/", views.toggle_favorite, name="toggle_favorite"),
    path("api/add-to-playlist/", views.add_to_playlist, name="add_to_playlist"),
]
