from django.contrib import admin
from .models import Favorite, PlayHistory, Playlist, Song, UserProfile


@admin.register(Song)
class SongAdmin(admin.ModelAdmin):
    list_display = ("title", "artist", "album", "genre", "duration", "play_count", "uploaded_by")
    search_fields = ("title", "artist", "album", "genre")
    list_filter = ("genre", "uploaded_by")


@admin.register(Playlist)
class PlaylistAdmin(admin.ModelAdmin):
    list_display = ("name", "owner", "created_at")
    search_fields = ("name", "owner__username")


@admin.register(PlayHistory)
class PlayHistoryAdmin(admin.ModelAdmin):
    list_display = ("song", "user", "played_at")
    list_filter = ("played_at",)


admin.site.register(Favorite)
admin.site.register(UserProfile)
