from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.core.paginator import Paginator
from django.db.models import Count, F, Q, Sum
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST
from .models import Favorite, PlayHistory, Playlist, Song


# =============================================================================
# HOME – Community music discovery
# =============================================================================
def home(request):
    query = request.GET.get("q", "").strip()
    sort = request.GET.get("sort", "latest")
    songs = Song.objects.select_related("uploaded_by").all()

    if query:
        songs = songs.filter(Q(title__icontains=query) | Q(artist__icontains=query))

    if sort == "popular":
        songs = songs.order_by("-play_count")
    elif sort == "title":
        songs = songs.order_by("title")
    else:
        songs = songs.order_by("-created_at")

    # Trending: top 8 songs by play count
    trending = Song.objects.order_by("-play_count")[:8]

    # Fresh uploads: latest 8 songs
    fresh = Song.objects.order_by("-created_at")[:8]

    favorite_ids = set()
    playlists = []
    if request.user.is_authenticated:
        favorite_ids = set(
            Favorite.objects.filter(user=request.user).values_list("song_id", flat=True)
        )
        playlists = Playlist.objects.filter(owner=request.user)

    return render(request, "music/home.html", {
        "songs": songs,
        "trending": trending,
        "fresh": fresh,
        "query": query,
        "sort": sort,
        "favorite_ids": favorite_ids,
        "playlists": playlists,
    })


# =============================================================================
# MY UPLOADS – Any logged-in user can upload & manage their own songs
# =============================================================================
@login_required
def my_uploads(request):
    query = request.GET.get("q", "").strip()
    edit_id = request.GET.get("edit")

    # Only this user's songs
    songs = Song.objects.filter(uploaded_by=request.user)

    if query:
        songs = songs.filter(Q(title__icontains=query) | Q(artist__icontains=query))

    songs = songs.order_by("-created_at")

    # --- POST: add / edit / delete ---
    if request.method == "POST":
        delete_id = request.POST.get("delete_id")
        if delete_id:
            song = get_object_or_404(Song, pk=delete_id, uploaded_by=request.user)
            song.delete()
            messages.success(request, f'Deleted "{song.title}".')
            return redirect("my_uploads")

        song_id = request.POST.get("song_id")
        title = request.POST.get("title", "").strip()
        artist = request.POST.get("artist", "").strip()
        album = request.POST.get("album", "").strip()
        genre = request.POST.get("genre", "").strip()
        duration = request.POST.get("duration", "0")

        if not title or not artist:
            messages.error(request, "Title and Artist are required.")
            return redirect("my_uploads")

        try:
            duration = int(duration)
        except (ValueError, TypeError):
            duration = 0

        if song_id:
            # EDIT existing song (only own songs)
            song = get_object_or_404(Song, pk=song_id, uploaded_by=request.user)
            song.title = title
            song.artist = artist
            song.album = album
            song.genre = genre
            song.duration = duration
            if request.FILES.get("audio_file"):
                song.audio_file = request.FILES["audio_file"]
            if request.FILES.get("cover_image"):
                song.cover_image = request.FILES["cover_image"]
            song.save()
            messages.success(request, f'Updated "{title}".')
        else:
            # ADD new song
            song = Song(
                title=title,
                artist=artist,
                album=album,
                genre=genre,
                duration=duration,
                uploaded_by=request.user,
            )
            if request.FILES.get("audio_file"):
                song.audio_file = request.FILES["audio_file"]
            if request.FILES.get("cover_image"):
                song.cover_image = request.FILES["cover_image"]
            song.save()
            messages.success(request, f'Uploaded "{title}"!')

        return redirect("my_uploads")

    # --- GET ---
    paginator = Paginator(songs, 15)
    page_number = request.GET.get("page", 1)
    page_obj = paginator.get_page(page_number)

    edit_song = None
    if edit_id:
        try:
            edit_song = Song.objects.get(pk=edit_id, uploaded_by=request.user)
        except Song.DoesNotExist:
            pass

    return render(request, "music/my_uploads.html", {
        "songs": songs,
        "page_obj": page_obj,
        "query": query,
        "edit_song": edit_song,
        "editing": edit_song is not None,
    })


# =============================================================================
# USER PROFILE – See any user's uploaded songs
# =============================================================================
def user_profile(request, username):
    profile_user = get_object_or_404(User, username=username)
    songs = Song.objects.filter(uploaded_by=profile_user).order_by("-created_at")
    song_count = songs.count()
    total_plays = songs.aggregate(total=Sum("play_count"))["total"] or 0
    return render(request, "music/user_profile.html", {
        "profile_user": profile_user,
        "songs": songs,
        "song_count": song_count,
        "total_plays": total_plays,
    })


# =============================================================================
# API & utility views
# =============================================================================
def song_detail(request, song_id):
    song = get_object_or_404(Song, pk=song_id)
    return JsonResponse({
        "id": song.id,
        "title": song.title,
        "artist": song.artist,
        "album": song.album,
        "genre": song.genre,
        "audio_url": song.audio_file.url if song.audio_file else "",
        "cover_url": song.cover_image.url if song.cover_image else "",
        "duration": song.duration,
        "uploaded_by": song.uploaded_by.username if song.uploaded_by else "Unknown",
        "is_favorite": request.user.is_authenticated
        and Favorite.objects.filter(user=request.user, song=song).exists(),
    })


def register(request):
    form = UserCreationForm(request.POST or None)
    if form.is_valid():
        user = form.save()
        login(request, user)
        return redirect("home")
    return render(request, "music/auth/register.html", {"form": form})


@login_required
def favorites(request):
    songs = Song.objects.filter(favorited_by__user=request.user)
    return render(request, "music/favorites.html", {"songs": songs})


@login_required
def recently_played(request):
    history = PlayHistory.objects.filter(user=request.user).select_related("song")[:50]
    return render(request, "music/recently_played.html", {"history": history})


@login_required
def create_playlist(request):
    name = request.POST.get("name", "").strip()
    if request.method == "POST" and name:
        Playlist.objects.get_or_create(owner=request.user, name=name)
        messages.success(request, "Playlist created.")
    return redirect("home")


@login_required
@require_POST
def record_play(request):
    song = get_object_or_404(Song, pk=request.POST.get("song_id"))
    PlayHistory.objects.create(user=request.user, song=song)
    Song.objects.filter(pk=song.pk).update(play_count=F("play_count") + 1)
    return JsonResponse({"ok": True})


@login_required
@require_POST
def toggle_favorite(request):
    song = get_object_or_404(Song, pk=request.POST.get("song_id"))
    favorite, created = Favorite.objects.get_or_create(user=request.user, song=song)
    if not created:
        favorite.delete()
    return JsonResponse({"is_favorite": created})


@login_required
@require_POST
def add_to_playlist(request):
    song = get_object_or_404(Song, pk=request.POST.get("song_id"))
    playlist = get_object_or_404(
        Playlist, pk=request.POST.get("playlist_id"), owner=request.user
    )
    playlist.songs.add(song)
    return JsonResponse({"ok": True})


# =============================================================================
# Admin Song Management (staff only)
# =============================================================================
def _is_staff(user):
    return user.is_active and (user.is_staff or user.is_superuser)


@user_passes_test(_is_staff)
def manage_songs(request):
    query = request.GET.get("q", "").strip()
    edit_id = request.GET.get("edit")

    if request.method == "POST":
        delete_id = request.POST.get("delete_id")
        if delete_id:
            song = get_object_or_404(Song, pk=delete_id)
            song.delete()
            messages.success(request, f'Deleted "{song.title}".')
            return redirect("manage_songs")

        song_id = request.POST.get("song_id")
        title = request.POST.get("title", "").strip()
        artist = request.POST.get("artist", "").strip()
        album = request.POST.get("album", "").strip()
        genre = request.POST.get("genre", "").strip()
        duration = request.POST.get("duration", "0")

        if not title or not artist:
            messages.error(request, "Title and Artist are required.")
            return redirect("manage_songs")

        try:
            duration = int(duration)
        except (ValueError, TypeError):
            duration = 0

        if song_id:
            song = get_object_or_404(Song, pk=song_id)
            song.title = title
            song.artist = artist
            song.album = album
            song.genre = genre
            song.duration = duration
            if request.FILES.get("audio_file"):
                song.audio_file = request.FILES["audio_file"]
            if request.FILES.get("cover_image"):
                song.cover_image = request.FILES["cover_image"]
            song.save()
            messages.success(request, f'Updated "{title}".')
        else:
            song = Song(
                title=title,
                artist=artist,
                album=album,
                genre=genre,
                duration=duration,
                uploaded_by=request.user,
            )
            if request.FILES.get("audio_file"):
                song.audio_file = request.FILES["audio_file"]
            if request.FILES.get("cover_image"):
                song.cover_image = request.FILES["cover_image"]
            song.save()
            messages.success(request, f'Added "{title}".')

        return redirect("manage_songs")

    songs = Song.objects.select_related("uploaded_by").all()
    if query:
        songs = songs.filter(Q(title__icontains=query) | Q(artist__icontains=query))
    songs = songs.order_by("-created_at")

    paginator = Paginator(songs, 15)
    page_number = request.GET.get("page", 1)
    page_obj = paginator.get_page(page_number)

    edit_song = None
    if edit_id:
        try:
            edit_song = Song.objects.get(pk=edit_id)
        except Song.DoesNotExist:
            pass

    return render(request, "music/manage_songs.html", {
        "songs": songs,
        "page_obj": page_obj,
        "query": query,
        "edit_song": edit_song,
        "editing": edit_song is not None,
    })
