#!/usr/bin/env bash
set -e

# Ensure environment variables are available
: ${DJANGO_SETTINGS_MODULE:=musicplayer.settings}

echo "==> Running migrations..."
python manage.py makemigrations --noinput 2>/dev/null || true
python manage.py migrate --noinput

echo "==> Collecting static files..."
python manage.py collectstatic --noinput --clear 2>/dev/null || python manage.py collectstatic --noinput

# Create superuser automatically if env vars are set (safe - will ignore if exists)
if [[ -n "$DJANGO_SUPERUSER_USERNAME" && -n "$DJANGO_SUPERUSER_PASSWORD" ]]; then
    echo "==> Creating superuser (if not exists)..."
    python manage.py shell -c "
import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'musicplayer.settings')
import django
django.setup()
from django.contrib.auth import get_user_model
User = get_user_model()
username = os.environ.get('DJANGO_SUPERUSER_USERNAME', 'admin')
password = os.environ.get('DJANGO_SUPERUSER_PASSWORD', 'admin123')
email = os.environ.get('DJANGO_SUPERUSER_EMAIL', 'admin@example.com')
if not User.objects.filter(username=username).exists():
    User.objects.create_superuser(username, email, password)
    print(f'Superuser \"{username}\" created.')
else:
    print(f'Superuser \"{username}\" already exists.')
" 2>/dev/null || true
fi

if [ "$1" = "shell" ]; then
  shift
  exec python manage.py shell "$@"
fi

if [ "$1" = "migrate" ]; then
  echo "==> Migration complete. Exiting."
  exit 0
fi

echo "==> Starting gunicorn..."
exec gunicorn musicplayer.wsgi:application \
    --bind 0.0.0.0:${PORT:-8000} \
    --workers 3 \
    --access-logfile - \
    --error-logfile - \
    --log-level info
